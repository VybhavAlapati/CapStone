package Shop_For_Home_C1_G7First_Microservice.enums;

public interface CodeEnum {
    Integer getCode();

}