package Shop_For_Home_C7_G3First_Microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopForHomeC1G7FirstMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
